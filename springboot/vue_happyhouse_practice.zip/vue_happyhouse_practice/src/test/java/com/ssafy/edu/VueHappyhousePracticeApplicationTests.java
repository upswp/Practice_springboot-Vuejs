package com.ssafy.edu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VueHappyhousePracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
